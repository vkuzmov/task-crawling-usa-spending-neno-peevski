API_URL = 'https://api.usaspending.gov/api/v2/recipient/'
URL_PER_YEAR = 'https://api.usaspending.gov/api/v2/search/new_awards_over_time/'

HEADERS = {
    "authority": "api.usaspending.gov",
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9,bg;q=0.8",
    "content-type": "application/json",
    "origin": "https://www.usaspending.gov",
    "referer": "https://www.usaspending.gov/",
    "sec-ch-ua": "\"Google Chrome\";v=\"107\", \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Linux\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
    "x-requested-with": "USASpendingFrontend"
}
HEADERS_TRANSACTIOS = {
    "authority": "api.usaspending.gov",
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9,bg;q=0.8",
    "origin": "https://www.usaspending.gov",
    "referer": "https://www.usaspending.gov/",
    "sec-ch-ua": "\"Google Chrome\";v=\"107\", \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Linux\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
    "x-requested-with": "USASpendingFrontend"
}
HEADERS_PER_YEAR = {
    "authority": "api.usaspending.gov",
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9,bg;q=0.8",
    "content-type": "application/json",
    "origin": "https://www.usaspending.gov",
    "referer": "https://www.usaspending.gov/",
    "sec-ch-ua": "\"Google Chrome\";v=\"107\", \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Linux\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
    "x-requested-with": "USASpendingFrontend"
}


def create_body(page):
    body = {"order": "desc", "sort": "amount", "page": page, "limit": 50, "award_type": "all"}
    return body


def create_body_per_year(item_id):
    body = {"group": "fiscal_year",
            "filters": {"recipient_id": item_id,
                        "time_period": [
                            {"start_date": "2007-10-01",
                             "end_date": "2023-09-30"}]}}

    return body
