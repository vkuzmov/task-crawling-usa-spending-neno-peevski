# -*- coding: utf-8 -*-
import scrapy
from scrapy.loader import ItemLoader
from ..utils import API_URL, HEADERS, create_body, HEADERS_TRANSACTIOS, URL_PER_YEAR, create_body_per_year, \
    HEADERS_PER_YEAR
from ..items import UsaspendingItem
import json


class SpendingSpider(scrapy.Spider):
    name = 'usa_spending'
    allowed_domains = ['www.usaspending.gov']
    start_urls = ['http://www.usaspending.gov/']

    def start_requests(self):
        body = create_body(1)

        yield scrapy.Request(
            url=API_URL,
            method='POST',
            callback=self.parse_main_page,
            dont_filter=True,
            body=json.dumps(body),
            headers=HEADERS,
            meta={
                'currentPage': 1
            }
        )

    def parse_main_page(self, response):
        current_page = response.meta['currentPage']
        json_resp = json.loads(response.body)

        items = json_resp.get('results')
        for item in items:
            loader = ItemLoader(item=UsaspendingItem())
            item_id = item.get('id')
            url = f'https://www.usaspending.gov/recipient/{item_id}/latest'

            loader.add_value('item_id', item_id)
            loader.add_value('url', url)
            loader.add_value('name', item.get('name'))
            loader.add_value('uei', item.get('uei'))
            loader.add_value('duns', item.get('duns'))
            loader.add_value('awarded_amount', item.get('amount'))

            url_transactions = f'https://api.usaspending.gov/api/v2/recipient/{item_id}/?year=latest'

            yield response.follow(url_transactions,
                                  callback=self.extract_transactions,
                                  method='GET',
                                  dont_filter=True,
                                  headers=HEADERS_TRANSACTIOS,
                                  meta={'item': loader.load_item()})

        total_pages = 20  # 20*500 = 1000 items scrapped
        if current_page < total_pages:
            current_page += 1
            body = create_body(current_page)
            yield scrapy.Request(
                url=API_URL,
                method='POST',
                callback=self.parse_main_page,
                dont_filter=True,
                body=json.dumps(body),
                headers=HEADERS,
                meta={
                    'currentPage': current_page
                }
            )

    def extract_transactions(self, response):
        loader = ItemLoader(item=UsaspendingItem(response.meta.get('item', {})), selector=response)
        json_resp = json.loads(response.body)
        transactions = json_resp.get('total_transactions')
        loader.replace_value('transactions', transactions)
        item_id = loader.get_output_value('item_id')
        body = create_body_per_year(item_id)

        yield response.follow(URL_PER_YEAR,
                              callback=self.extract_amount_per_year,
                              method='POST',
                              dont_filter=True,
                              body=json.dumps(body),
                              headers=HEADERS_PER_YEAR,
                              meta={'item': loader.load_item()})

    def extract_amount_per_year(self, response):

        amount_per_year = []
        loader = ItemLoader(item=UsaspendingItem(response.meta.get('item', {})), selector=response)
        json_resp = json.loads(response.body)
        results = json_resp.get('results')
        for result in results:
            amount_per_year.append(result.get('new_award_count_in_period'))

        loader.replace_value('amount_per_year', amount_per_year)

        yield loader.load_item()
