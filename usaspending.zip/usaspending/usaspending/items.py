# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import TakeFirst


class UsaspendingItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    item_id = scrapy.Field(output_processor=TakeFirst())
    url = scrapy.Field(output_processor=TakeFirst())
    name = scrapy.Field(output_processor=TakeFirst())
    uei = scrapy.Field(output_processor=TakeFirst())
    duns = scrapy.Field(output_processor=TakeFirst())
    awarded_amount = scrapy.Field(output_processor=TakeFirst())
    transactions = scrapy.Field(output_processor=TakeFirst())
    amount_per_year = scrapy.Field()
