page = 1
body = {"order": "desc", "sort": "amount", "page": page, "limit": 50, "award_type": "all"}


# print(body)
# str_body = str(body)
# print(type(str_body))
# print(str_body)

# BODY = {"order": "desc", "sort": "amount", "page": 1, "limit": 50, "award_type": "all"}
# print(BODY)
# print(type(BODY))


# HEADERS = {"content-type": "application/json"}
# print(HEADERS)
# print(type(HEADERS))
#
# print('****************************************')
#
# headers_str = str(HEADERS)
# print(headers_str)
# print(type(headers_str))

def create_body_per_year(item_id):
    # body = {"group": "fiscal_year",
    #         "filters": {"recipient_id": {item_id},
    #                     "time_period": [
    #                         {"start_date": "2007-10-01", "end_date": "2023-09-30"}]}}

    body_part_1 = '{"group":"fiscal_year","filters":{"recipient_id":"'
    body_part_2 = '","time_period":[{"start_date":"2007-10-01","end_date":"2023-09-30"}]}}'
    return f'{body_part_1}{item_id}{body_part_2}'

print(create_body_per_year(1000))