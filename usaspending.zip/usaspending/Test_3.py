# -*- coding: utf-8 -*-
import json
import re

from bw_scrapy_core.spiders import BwApiSpider
from bw_scrapy_core.loader import BWItemLoader
from element5.spiders.element5by_base import Element5ByBase
from element5.items import Element5Item


class Element5ByEntryPage(Element5ByBase, BwApiSpider):
    name = 'entry_page_element5by'

    def start_requests_iter(self, response):
        for entry in self.fetch_entry_pages():
            for url in entry['links']:
                yield response.follow(url,
                                      callback=self.configure_api_request,
                                      meta={'entry_page_product': entry.get('product'),
                                            'product_category_link': url})

    def configure_api_request(self, response):
        last_part_link = response.meta.get('product_category_link').split('/')[-1]
        link_id = re.search(r'\d+', last_part_link)

        category_info = response.css('.g-main.ec-category-item::attr(data-ec_category_info)').get()
        category_id_dict = json.loads(category_info)
        self.settings['POST_REQUEST']['params']['categoryId'] = category_id_dict.get('id', '')

        if link_id:
            link_id = link_id.group(0)
            self.settings['POST_REQUEST']['link'] = self.settings['POST_REQUEST']['link'].format(link_id)
            yield response.follow(self.settings.get('POST_REQUEST', '').get('link', ''),
                                  callback=self.parse_list_response,
                                  method="POST",
                                  headers=self.settings.get('POST_REQUEST', {}).get('headers', {}),
                                  body=self.create_body(self.settings.get('POST_REQUEST').get('params', {})),
                                  meta={'entry_page_product': response.meta.get('entry_page_product')})

    def parse_list_response(self, response):
        entry_page_product = response.meta.get('entry_page_product')
        resp_dict = response.json()
        breadcrumbs = [b.get('TITLE') for b in resp_dict.get('breadcrumbs', [])]

        for item in resp_dict.get('products', []):
            loader = BWItemLoader(item=Element5Item(response.meta.get('item', {})), selector=item)
            url = response.urljoin(item.get('urlToProductPage', ''))
            loader.add_value('url', url)

            loader.add_value('list_url', response.url)
            loader.add_value('entry_page_product', entry_page_product)
            loader.add_value('breadcrumbs', breadcrumbs)

            loader.add_value('article_id', item.get('patioCode', ''))
            loader.add_value('price', str(item.get('price', '')))

            if not loader.get_output_value('article_id'):
                links = f"{loader.get_output_value('url')} | list_url: {loader.get_output_value('list_url')}"
                self.logger.info(f"article_id doesn't exists - {links}")
                continue

            yield loader.load_item()

        next_num_page = resp_dict.get('currentPage') + 1
        if next_num_page <= int(resp_dict.get('pageCount', '')):
            post_request = self.settings.get('POST_REQUEST', {})
            post_request['params']['currentPage'] = next_num_page
            yield response.follow(post_request.get('link'),
                                  callback=self.parse_list_response,
                                  method="POST",
                                  headers=post_request.get('headers', {}),
                                  body=self.create_body(post_request.get('params')),
                                  meta={'entry_page_product': response.meta.get('entry_page_product')})

    def create_body(self, post_data_dict):
        sufix = '------WebKitFormBoundaryelnFi3BdBGlx6Ika'
        posfix = '\r\nContent-Disposition: form-data; name='
        params = [f'{sufix}{posfix}"{k}"\r\n\r\n{v}\r\n' for k, v in post_data_dict.items()]
        return f"{''.join(params)}{sufix}--\r\n"
